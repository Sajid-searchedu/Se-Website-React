import React from 'react';

import WebBnanner1 from "../assets/img/WebBanner–1.jpg";
import WebBnanner2 from "../assets/img/WebBanner–2.jpg";
import WebBnanner3 from "../assets/img/WebBanner–3.jpg";
import WebBnanner4 from "../assets/img/live-banner05.jpeg";
import WebBnanner5 from "../assets/img/live-banner06.jpeg";


const LiveBaner = () => {
    return (
        <>

            <section className="live-Baner section-padding">
                <div className="container">
                    <div id="carouselLiveBanner" className="carousel slide" data-ride="carousel">
                        <div className="carousel-inner">
                            <div className="carousel-item active">
                                <a href="contactUs.html"> <img src={WebBnanner1} className="d-block w-100" alt="WebBanner–1" /></a>
                            </div>
                            <div className="carousel-item">
                                <a href="contactUs.html"> <img src={WebBnanner2} className="d-block w-100" alt="WebBanner–2" /></a>
                            </div>
                            <div className="carousel-item">
                                <a href="contactUs.html"> <img src={WebBnanner3} className="d-block w-100" alt="WebBanner–3" /></a>
                            </div>
                            <div className="carousel-item">
                                <a href="contactUs.html"> <img src={WebBnanner4} className="d-block w-100" alt="live-banner" /></a>
                            </div>
                            <div className="carousel-item">
                                <a href="contactUs.html"><img src={WebBnanner5} className="d-block w-100" alt="live-banner" /> </a>
                            </div>
                        </div>
                        <a className="carousel-control-prev" href="#carouselLiveBanner" role="button" data-slide="prev">
                            <i className="fa-2x fa fa-angle-left" aria-hidden="true"></i>
                            <span className="sr-only">Previous</span>
                        </a>
                        <a className="carousel-control-next" href="#carouselLiveBanner" role="button" data-slide="next">
                            <i className="fa-2x fa fa-angle-right" aria-hidden="true"></i>
                            <span className="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </section>

        </>
    )
}

export default LiveBaner
