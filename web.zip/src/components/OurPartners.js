import React from 'react';
import Slider from 'react-slick';

import HdfcCredial from "../assets/img/hdfc-credial-logo.png";
import Allianz from "../assets/img/allianz-logo.png";
import Amperstudent from "../assets/img/amperstudent.png";
import IdpIelts from "../assets/img/idp-ielts.png";
import Bupa from "../assets/img/bupa.png";
import LaLogo from "../assets/img/la-logo.jpg";



const OurPartners = () => {

    var settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 5,
        slidesToScroll: 1,
        initialSlide: 0,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 5,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: false
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    };

    return (
        <>
            <section className="section-padding our-partner" id="company">
                <div className="container">
                    <div className="body-title">
                        <h1>Our <span>Partners</span></h1>
                        <span className="title-border-btm"></span>
                    </div>
                    <div className="section-body mt-5">
                        <Slider {...settings} className="partner-logos slider text-center">
                            <div className="slide"><div className="education-partner-logo"><img src={HdfcCredial} alt="hdfc-credial" className="img-fluid" /></div></div>
                            <div className="slide"><div className="education-partner-logo"><img src={Allianz} alt="allianz" className="img-fluid" /></div></div>
                            <div className="slide"><div className="education-partner-logo"><img src={Amperstudent} alt="Ampers" className="img-fluid" /></div></div>
                            <div className="slide"><div className="education-partner-logo"><img src={IdpIelts} alt="idp-ielts" className="img-fluid" /></div></div>
                            <div className="slide"><div className="education-partner-logo"><img src={Bupa} alt="bupa" className="img-fluid" /></div></div>
                            <div className="slide"><div className="education-partner-logo"><img src={LaLogo} alt="la-logo" className="img-fluid" /></div></div>
                        </Slider>
                    </div>
                </div>
            </section>

        </>
    )
}

export default OurPartners
