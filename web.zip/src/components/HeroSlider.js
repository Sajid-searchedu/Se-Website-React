import React from 'react';

import SliderOne from "../assets/img/Ielts-web-banner.jpg";
import SliderTow from "../assets/img/unp-1.jpg";
import SliderThree from "../assets/img/unp-2.jpg";
import SliderFour from "../assets/img/unp-3.jpg";
import SliderFive from "../assets/img/unp-4.jpg";
import SliderSix from "../assets/img/unp-5.jpg";
import SliderSeven from "../assets/img/unp-6.jpg";
import SliderEight from "../assets/img/unp-7.jpg";

const HeroSlider = () => {
    return (
        <>
            <div id="carouselSEControls" className="carousel slide" data-ride="carousel">
                <div className="carousel-inner">
                    <div className="carousel-item active">
                        <img className="d-block w-100" src={SliderOne} alt="Ielts-web" />
                    </div>
                    <div className="carousel-item">
                        <img className="d-block w-100" src={SliderTow} alt="First slide" />
                    </div>
                    <div className="carousel-item">
                        <img className="d-block w-100" src={SliderThree} alt="Second slide" />
                    </div>
                    <div className="carousel-item">
                        <img className="d-block w-100" src={SliderFour} alt="Third slide" />
                    </div>
                    <div className="carousel-item">
                        <img className="d-block w-100" src={SliderFive} alt="Third slide" />
                    </div>
                    <div className="carousel-item">
                        <img className="d-block w-100" src={SliderSix} alt="Third slide" />
                    </div>
                    <div className="carousel-item">
                        <img className="d-block w-100" src={SliderSeven} alt="Third slide" />
                    </div>
                    <div className="carousel-item">
                        <img className="d-block w-100" src={SliderEight} alt="Third slide" />
                    </div>
                </div>
                <a className="carousel-control-prev" href="#carouselSEControls" role="button" data-slide="prev">
                    <i className="fa-2x fa fa-angle-left" aria-hidden="true"></i>
                    <span className="sr-only">Previous</span>
                </a>
                <a className="carousel-control-next" href="#carouselSEControls" role="button" data-slide="next">
                    <i className="fa-2x fa fa-angle-right" aria-hidden="true"></i>
                    <span className="sr-only">Next</span>
                </a>
            </div>

            <section>
                <div className="container">
                    <div className="DreamCourse">
                        <h4 className="DreamCourse-title">Search your Dream Course</h4>
                        <div className="search-course banner-search" id="searchBar-top">
                            <form>
                                <div className="input-group">
                                    <input type="text" className="form-control border-0" placeholder="Search Courses, Country & More...." data-toggle="modal" data-target="#SeSearchModal" />
                                </div>
                            </form>
                        </div>
                        <button className="btn ViewAll-btn pt-2 pb-2 ml-3" type="button">
                            <i className="fas fa-search"></i> Search
                        </button>
                    </div>
                </div>
            </section>
        </>
    )
}

export default HeroSlider
