import React from 'react';
import LiveBaner1 from "../assets/img/live-banner04.jpeg";
import LiveBaner2 from "../assets/img/live-banner07.jpeg";
import LiveBaner3 from "../assets/img/live-banner08.jpeg";


const LiveBanner2 = () => {
    return (
        <>
            <section className="live-Baner section-padding">
                <div className="container">
                    <div id="carouselLiveBanner2" className="carousel slide" data-ride="carousel">
                        <div className="carousel-inner">
                            <div className="carousel-item active">
                                <a href="contactUs.html"> <img src={LiveBaner1} className="d-block w-100" alt="live-banner4" /> </a>
                            </div>
                            <div className="carousel-item">
                                <a href="contactUs.html"><img src={LiveBaner2} className="d-block w-100" alt="live-banner7" /> </a>
                            </div>
                            <div className="carousel-item">
                                <a href="contactUs.html"><img src={LiveBaner3} className="d-block w-100" alt="live-banner8" /> </a>
                            </div>
                        </div>
                        <a className="carousel-control-prev" href="#carouselLiveBanner2" role="button" data-slide="prev">
                            <i className="fa-2x fa fa-angle-left" aria-hidden="true"></i>
                            <span className="sr-only">Previous</span>
                        </a>
                        <a className="carousel-control-next" href="#carouselLiveBanner2" role="button" data-slide="next">
                            <i className="fa-2x fa fa-angle-right" aria-hidden="true"></i>
                            <span className="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </section>
        </>
    )
}

export default LiveBanner2
