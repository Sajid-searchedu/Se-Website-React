import React from 'react';
import BrandLogo from "../assets/img/SE-logo.webp";
import Mara from "../assets/img/mara.png";
import Qeac from "../assets/img/qeac.png";

const Footer = () => {
    return (
        <>
        
            <footer className="footer-section">
                <div className="container">
                    <div className="footer-brand">
                        <a href="# "> <img src={BrandLogo} alt="Search Education" width="100%" /> </a>
                        <div className="email-subscribe">
                            <form>
                                <div className="input-group">
                                    <input type="text" className="form-control" placeholder="Enter Email id" />
                                    <div className="input-group-append">
                                        <button className=" border-0 subscribe-btn" type="button">
                                            Subscribe
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div className="subcribe-content">
                        <h6>SEARCH EDUCATION-  WHERE TECHNOLOGY, EXCELLENCE & UNDERSTANDING COME TOGETHER</h6>
                        <p>Facilitating students acquire perfect-fit education placements that ultimately changes their lives! Established in 2015, Search Education strives to bring your overseas education dreams to life. We offer an exceptionally customized service that surpasses the expectation of clients. International reach and established global offices work round the clock to engage with a diverse range of educationists to cater to the specific needs of clients.</p>
                    </div>

                    <div className="verified-partner text-center">
                        <img src={Mara} alt="mara" width="10%" />
                        <img src={Qeac} alt="qeac" width="16%" />
                    </div>
                </div>
            </footer>



            <section>
                <div className="footer-broder-top">
                    <div className="container">
                        <p>&copy; {(new Date().getFullYear())} <a href="https://searcheducation.com/">SEAREDUCATION.COM</a> ALL RIGHTS RESERVED.</p>
                    </div>
                </div>
            </section>

            <section>
                <div className="call-icon" data-toggle="modal" data-target="#iframeModal">
                    <a href="book-appointment.html"> <i className="fa fa-calendar-check-o" aria-hidden="true"></i> <span>Book Now</span></a>
                </div>
            </section>

            <section>
                <div id="calculateNav">
                    <a href="points-calculator.html" >Visa Point Calculator<i className="fas fa-calculator"></i></a>
                </div>
            </section>
        </>
    )
}

export default Footer
