import React from 'react';
import Slider from 'react-slick';
import RamanGhel from "../assets/img/raman-ghel.webp";
import IshaChauhan from "../assets/img/isha-chauhan.png";
import ReviewMale from "../assets/img/review-male.png";
import ShwetaRawal from "../assets/img/Shweta-Rawal.webp";
import ankitSaini from "../assets/img/ankit-saini.webp";
import rakeshT from "../assets/img/rakesh-t.png";
import SaloniBhattarai from "../assets/img/Saloni-Bhattarai.png";

const PeopleSay = () => {

    var settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 5,
        slidesToScroll: 1,
        initialSlide: 0,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 5,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: false
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            }
        ]
    };
    return (
        <>

            <section className="popular-body section-padding bg-f3f3f3" >
                <div className="container">
                    <div className="body-title">
                        <h1>WHAT PEOPLE SAY <br /> <span>ABOUT US</span></h1>
                        <span className="title-border-btm"></span>
                    </div>
                    <div className="section-body reviews searchCity">

                        <div className="modal fade" id="myModal2" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div className="modal-dialog" role="document">
                                <div className="modal-content">
                                    <div className="modal-body">
                                        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                        <div className="embed-responsive embed-responsive-16by9">
                                            <iframe className="embed-responsive-item" src="" id="video" allowscriptaccess="always" allow="autoplay" title="videoModal"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <Slider {...settings} className="countrySlide slider">

                            <div className="slide">
                                <div className="blogCardNew blog-Review-vedio">
                                    <div className="blogOveralyNew video-btn" data-toggle="modal" data-src="https://www.youtube.com/embed/f2aLPPTZGqQ" data-target="#myModal2">
                                        <i className="fa-4x fa fa-play-circle " aria-hidden="true"></i>
                                    </div>
                                    <div className="blogCard-imgNew" >
                                        <img src={RamanGhel} alt="unser" />
                                    </div>
                                    <div className="blogCard-contentNew vedio-text">
                                        <h4>Raman Ghale </h4>
                                    </div>
                                </div>
                            </div>
                            <div className="slide">
                                <div className="blogCardNew">
                                    <div className="blogOveralyNew blogOveralyNew-text"></div>
                                    <div className="blogCard-imgNew">
                                    </div>
                                    <div className="blogcountryNew">
                                        <span className="blogCountryNameNew">
                                            <i className="fa fa-quote-left" aria-hidden="true"></i> <br />
                                        </span>
                                        <span className="humberCountryNew">
                                            <div className="blog-star">
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                            </div>
                                        </span>
                                    </div>
                                    <div className="blogCard-contentNew review-content">
                                        <div className="rounded-img-body"><img src={IshaChauhan} alt="unser" /></div>
                                        <h4>Isha Chauhan</h4>
                                        <p>I had a great experience with Search Education. The communication was effortless and of good valye. Sakshi ma'am helped me every step of the way and ensured all my questions were answered. </p>
                                    </div>
                                </div>
                            </div>


                            <div className="slide">
                                <div className="blogCardNew">
                                    <div className="blogOveralyNew blogOveralyNew-text"></div>
                                    <div className="blogCard-imgNew">
                                    </div>
                                    <div className="blogcountryNew">
                                        <span className="blogCountryNameNew">
                                            <i className="fa fa-quote-left" aria-hidden="true"></i> <br />

                                        </span>
                                        <span className="humberCountryNew">
                                            <div className="blog-star">
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                            </div>
                                        </span>
                                    </div>
                                    <div className="blogCard-contentNew review-content">
                                        <div className="rounded-img-body"><img src={ReviewMale} alt="unser" /></div>
                                        <h4>Bhanu Pratap</h4>
                                        <p>Had a great experience with search education.All the staff is quite helpful and professional. They made me aware about all the procedure throughout the application process. </p>
                                    </div>
                                </div>
                            </div>

                            <div className="slide">
                                <div className="blogCardNew blog-Review-vedio">
                                    <div className="blogOveralyNew video-btn" data-toggle="modal" data-src="https://www.youtube.com/embed/zGO76IJe1HA" data-target="#myModal2">
                                        <i className="fa-4x fa fa-play-circle " aria-hidden="true"></i>
                                    </div>
                                    <div className="blogCard-imgNew" >
                                        <img src={ShwetaRawal} alt="unser" />
                                    </div>
                                    <div className="blogCard-contentNew vedio-text">
                                        <h4>Shweta Rawal</h4>
                                    </div>
                                </div>
                            </div>

                            <div className="slide">
                                <div className="blogCardNew">
                                    <div className="blogOveralyNew blogOveralyNew-text"></div>
                                    <div className="blogCard-imgNew">
                                    </div>
                                    <div className="blogcountryNew">
                                        <span className="blogCountryNameNew">
                                            <i className="fa fa-quote-left" aria-hidden="true"></i> <br />

                                        </span>
                                        <span className="humberCountryNew">
                                            <div className="blog-star">
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                            </div>
                                        </span>
                                    </div>
                                    <div className="blogCard-contentNew review-content">
                                        <div className="rounded-img-body"><img src={ReviewMale} alt="unser" /></div>
                                        <h4>Vaibhav Pahuja</h4>
                                        <p>Been an amazing so far. I always wished to study abroad and Search Education helped me conquer that dream. Best thing about Search Education is the independence you get while choosing your own type of college. </p>
                                    </div>
                                </div>
                            </div>
                            <div className="slide">
                                <div className="blogCardNew blog-Review-vedio">
                                    <div className="blogOveralyNew video-btn" data-toggle="modal" data-src="https://www.youtube.com/embed/2nPwT--C0v0" data-target="#myModal2">
                                        <i className="fa-4x fa fa-play-circle " aria-hidden="true"></i>
                                    </div>
                                    <div className="blogCard-imgNew" >
                                        <img src={ankitSaini} alt="unser" />
                                    </div>
                                    <div className="blogCard-contentNew vedio-text">
                                        <h4>Ankit Saini </h4>
                                    </div>
                                </div>
                            </div>
                            <div className="slide">
                                <div className="blogCardNew">
                                    <div className="blogOveralyNew blogOveralyNew-text"></div>
                                    <div className="blogCard-imgNew">
                                    </div>
                                    <div className="blogcountryNew">
                                        <span className="blogCountryNameNew">
                                            <i className="fa fa-quote-left" aria-hidden="true"></i> <br />

                                        </span>
                                        <span className="humberCountryNew">
                                            <div className="blog-star">
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                            </div>
                                        </span>
                                    </div>
                                    <div className="blogCard-contentNew review-content">
                                        <div className="rounded-img-body"><img src={rakeshT} alt="unser" /></div>
                                        <h4>Rakesh Tamang</h4>
                                        <p>One the best institution to study IELTS with experienced tutors... And they also provide free counselling to every students who are dreaming to study abroad.</p>
                                    </div>
                                </div>
                            </div>

                            <div className="slide">
                                <div className="blogCardNew">
                                    <div className="blogOveralyNew blogOveralyNew-text"></div>
                                    <div className="blogCard-imgNew">
                                    </div>
                                    <div className="blogcountryNew">
                                        <span className="blogCountryNameNew">
                                            <i className="fa fa-quote-left" aria-hidden="true"></i> <br />

                                        </span>
                                        <span className="humberCountryNew">
                                            <div className="blog-star">
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                                <i className="fas fa-star"> </i>
                                            </div>
                                        </span>
                                    </div>
                                    <div className="blogCard-contentNew review-content">
                                        <div className="rounded-img-body"><img src={SaloniBhattarai} alt="unser" /></div>
                                        <h4>Saloni Bhattarai</h4>
                                        <p>Thank yuh search education Sydney  for showing me the pathway to extend my visa in the very short period of time .. The staff and all the team are very cooperative .. they won’t let u have even a single doubt regarding  processing. </p>
                                    </div>
                                </div>
                            </div>

                        </Slider>
                    </div>
                </div>
            </section>

        </>
    )
}

export default PeopleSay
