import React from 'react';
import Branchmap from "../assets/img/map.webp";
import SedIcon from "../assets/img/SED-icon2.png";

const GetInTouch = () => {
    return (
        <>
            <section className="section-padding" >
                <div className="container">
                    <div className="body-title">
                        <h1>GET IN <span>TOUCH</span></h1>
                        <span className="title-border-btm"></span>
                    </div>
                    <div className="section-body pt-0">
                        <div className="GetInTouch">
                            <div className="row">
                                <div className="col-lg-7 col-md-7 col-12">
                                    <div className="get-map">
                                        <img src={Branchmap} alt="map" className="img-fluid" />
                                        <div className="icon-adress-position">
                                            <div className="map-mark">
                                                <div className="map-icon">
                                                    <img src={SedIcon} alt="SED-icon2" className="" />
                                                </div>
                                                <div className="map-mark-address">
                                                    <h6>MAHENDRANAGAR, NEPAL</h6>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="icon-adress-position1">
                                            <div className="map-mark">
                                                <div className="map-icon">
                                                    <img src={SedIcon} alt="SED-icon2" className="" />
                                                </div>
                                                <div className="map-mark-address">
                                                    <h6>Kathmandu, Nepal</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="icon-adress-position7">
                                            <div className="map-mark">
                                                <div className="map-icon">
                                                    <img src={SedIcon} alt="SED-icon2" className="" />
                                                </div>
                                                <div className="map-mark-address">
                                                    <h6>DANG, NEPAL</h6>

                                                </div>
                                            </div>
                                        </div>

                                        <div className="icon-adress-position2">
                                            <div className="map-mark">
                                                <div className="map-icon">
                                                    <img src={SedIcon} alt="SED-icon2" className="" />
                                                </div>
                                                <div className="map-mark-address">
                                                    <h6>Sydney, Australia</h6>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="icon-adress-position3">
                                            <div className="map-mark">
                                                <div className="map-icon">
                                                    <img src={SedIcon} alt="SED-icon2" className="" />
                                                </div>
                                                <div className="map-mark-address">
                                                    <h6>LAS CONDES, CHILE</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="icon-adress-position4">
                                            <div className="map-mark">
                                                <div className="map-icon">
                                                    <img src={SedIcon} alt="SED-icon2" className="" />
                                                </div>
                                                <div className="map-mark-address">
                                                    <h6>Sri Nagar, India</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="icon-adress-position5">
                                            <div className="map-mark">
                                                <div className="map-icon">
                                                    <img src={SedIcon} alt="SED-icon2" className="" />
                                                </div>
                                                <div className="map-mark-address">
                                                    <h6>Chandigarh, India</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="icon-adress-position6">
                                            <div className="map-mark">
                                                <div className="map-icon">
                                                    <img src={SedIcon} alt="SED-icon2" className="" />
                                                </div>
                                                <div className="map-mark-address">
                                                    <h6>Delhi, India</h6>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="city-address">
                                        <div className="map-country-adress">
                                            <ul className="nav nav-pills text-center" id="pills-tab3" role="tablist">
                                                <li className="nav-item">
                                                    <a className="nav-link active" id="India1-tab" data-toggle="pill" href="#India1" role="tab" aria-controls="India1" aria-selected="true">India</a>
                                                </li>
                                                <li className="nav-item">
                                                    <a className="nav-link" id="India2-tab" data-toggle="pill" href="#India2" role="tab" aria-controls="India2" aria-selected="true">AUSTRALIA</a>
                                                </li>
                                                <li className="nav-item">
                                                    <a className="nav-link" id="India3-tab" data-toggle="pill" href="#India3" role="tab" aria-controls="India3" aria-selected="true">NEPAL</a>
                                                </li>
                                                <li className="nav-item">
                                                    <a className="nav-link" id="India5-tab" data-toggle="pill" href="#India5" role="tab" aria-controls="India5" aria-selected="true">CHILE</a>
                                                </li>
                                            </ul>
                                        </div>

                                        <div className="tab-content" id="pills-tabContent3">
                                            <div className="tab-pane fade show active" id="India1" role="tabpanel" aria-labelledby="India1-tab">
                                                <div className="row">
                                                    <div className="col-md-4">
                                                        <div className="state-adress">
                                                            <h6>India - Delhi</h6>
                                                            <p>Office no. 111-112, 114-115, <br />Office no. 1409-1412 (14th Floor), 38 Ansal Tower, Nehru Place, New Delhi, 110019 <br />
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div className="col-md-4">
                                                        <div className="state-adress">
                                                            <h6>India - Sri Nagar</h6>
                                                            <p>Top Floor, Mir Mall, Opposite District Police Lines, Balgarden,Karan Nagar rd,Srinagar, Jammu and Kashmir, 190010 <br />
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div className="col-md-4">
                                                        <div className="state-adress">
                                                            <h6>India - Chandigarh</h6>
                                                            <p>SCO 491, First Floor, above Airtel Store, 35C, Chandigarh, 160022</p>
                                                        </div>
                                                    </div>
                                                    <div className="col-md-12">
                                                        <div className="social-country">
                                                            <span> <b>Connect via Social: </b></span>
                                                            <a href="https://www.instagram.com/searcheduindia/"> <i className="fa fa-instagram" aria-hidden="true"></i></a>
                                                            <a href="https://www.facebook.com/SearchEduIndia/"> <i className="fa fa-facebook-square" aria-hidden="true"></i></a>
                                                            <a href="https://www.linkedin.com/company/search-education/"> <i className="fa fa-linkedin-square" aria-hidden="true"></i></a>
                                                            <a href="https://www.youtube.com/channel/UCcxTTp8r0h7dimapsI8Yypg"> <i className="fa fa-youtube-square" aria-hidden="true"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="tab-pane fade show " id="India2" role="tabpanel" aria-labelledby="India2-tab">
                                                <div className="row">
                                                    <div className="col-md-4">
                                                        <div className="state-adress">
                                                            <h6>Sydney - Australia</h6>
                                                            <p>Suite 501, 147 King Street, Sydney, NSW 2000 - Australia </p>
                                                        </div>
                                                    </div>
                                                    <div className="col-md-12">
                                                        <div className="social-country">
                                                            <span> <b>Connect via Social: </b></span>
                                                            <a href="https://www.instagram.com/searchedu/"> <i className="fa fa-instagram" aria-hidden="true"></i></a>
                                                            <a href="https://www.facebook.com/searchedusyd/"> <i className="fa fa-facebook-square" aria-hidden="true"></i></a>
                                                            <a href="https://www.linkedin.com/company/search-education/"> <i className="fa fa-linkedin-square" aria-hidden="true"></i></a>
                                                            <a href="https://www.youtube.com/channel/UCcxTTp8r0h7dimapsI8Yypg"> <i className="fa fa-youtube-square" aria-hidden="true"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="tab-pane fade show " id="India3" role="tabpanel" aria-labelledby="India3-tab">
                                                <div className="row">
                                                    <div className="col-md-4">
                                                        <div className="state-adress">
                                                            <h6>KATHMANDU -NEPAL</h6>
                                                            <p>Level 2, Bhim Plaza, (above KTM Bike showroom), Naxal Chowk, Kathmandu -Nepal </p>
                                                        </div>
                                                    </div>
                                                    <div className="col-md-4">
                                                        <div className="state-adress">
                                                            <h6>MAHENDRANAGAR - NEPAL</h6>
                                                            <p>Madan Chowk, Mahendranagar, Nepal</p>
                                                        </div>
                                                    </div>
                                                    <div className="col-md-4">
                                                        <div className="state-adress">
                                                            <h6>DANG -NEPAL</h6>
                                                            <p>Dang,Tulsipur 05, Ga line(Near Global IME Bank), Nepal</p>
                                                        </div>
                                                    </div>
                                                    <div className="col-md-12">
                                                        <div className="social-country">
                                                            <span> <b>Connect via Social: </b></span>
                                                            <a href="https://www.instagram.com/searchedunepal/"> <i className="fa fa-instagram" aria-hidden="true"></i></a>
                                                            <a href="https://www.facebook.com/SearchEduNepal"> <i className="fa fa-facebook-square" aria-hidden="true"></i></a>
                                                            <a href="https://www.linkedin.com/company/search-education/"> <i className="fa fa-linkedin-square" aria-hidden="true"></i></a>
                                                            <a href="https://www.youtube.com/channel/UCcxTTp8r0h7dimapsI8Yypg"> <i className="fa fa-youtube-square" aria-hidden="true"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="tab-pane fade show " id="India5" role="tabpanel" aria-labelledby="India5-tab">
                                                <div className="row">
                                                    <div className="col-md-4">
                                                        <div className="state-adress">
                                                            <h6>LAS CONDES - CHILE</h6>
                                                            <p>Av.Apoquindo 6550, Oficina 205, Las Condes, Chile</p>
                                                        </div>
                                                    </div>
                                                    <div className="col-md-12">
                                                        <div className="social-country">
                                                            <span> <b>Connect via Social: </b></span>
                                                            <a href="https://www.instagram.com/searchedu/"> <i className="fa fa-instagram" aria-hidden="true"></i></a>
                                                            <a href="https://www.facebook.com/searchedusyd/"> <i className="fa fa-facebook-square" aria-hidden="true"></i></a>
                                                            <a href="https://www.linkedin.com/company/search-education/"> <i className="fa fa-linkedin-square" aria-hidden="true"></i></a>
                                                            <a href="https://www.youtube.com/channel/UCcxTTp8r0h7dimapsI8Yypg"> <i className="fa fa-youtube-square" aria-hidden="true"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-5 col-md-5 col-12">
                                    <div className="map-locate">
                                        <div className="get-touch get-touch-bg">

                                            <p>Thinking to Study Abroad with Search Education? Fill in your details and our team will call you back at the earliest!</p>
                                            <form >
                                                <div className="row mt-3">
                                                    <div className="col-md-6">
                                                        <div className="form-group">
                                                            <label for="name">First Name*:</label>
                                                            <input type="text" className="form-control" placeholder="Jane" id="name" required="" />
                                                        </div>
                                                    </div>
                                                    <div className="col-md-6">
                                                        <div className="form-group">
                                                            <label for="lastname">Last Name*:</label>
                                                            <input type="text" className="form-control" placeholder="dev" id="lastname" required="" />
                                                        </div>
                                                    </div>
                                                    <div className="col-md-6">
                                                        <div className="form-group">
                                                            <label for="email">Email*:</label>
                                                            <input type="email" className="form-control" placeholder="Enter email" id="email" required="" />
                                                        </div>
                                                    </div>
                                                    <div className="col-md-6">
                                                        <div className="form-group">
                                                            <label for="number">Number*:</label>
                                                            <input type="text" className="form-control" placeholder="Ente Number" id="number" required="" />
                                                        </div>
                                                    </div>

                                                    <div className="col-md-6">
                                                        <div className="form-group">
                                                            <label for="lastName">Select Country*:</label>
                                                            <select id="country" name="country" className="form-control" required=""></select>
                                                        </div>
                                                    </div>

                                                    <div className="col-md-6">
                                                        <div className="form-group">
                                                            <label for="lastName">Select State*:</label>
                                                            <select name="state" id="state" className="form-control" required=""></select>
                                                        </div>
                                                    </div>


                                                    <div className="col-md-12">
                                                        <div className="form-group">
                                                            <label for="adress">Your message:</label>
                                                            <textarea className="form-control" rows="3" placeholder="Your message..."></textarea>
                                                        </div>
                                                    </div>
                                                </div>

                                                <button type="submit" className="btn btn-get-touch">Submit</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}

export default GetInTouch
