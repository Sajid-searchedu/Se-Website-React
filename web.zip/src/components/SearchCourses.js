import React from 'react';
import Slider from "react-slick";

import CourseOne from "../assets/img/PAUA-11.webp";
import CourseTwo from "../assets/img/PAUA-12.webp";
import CourseThree from "../assets/img/PAUA-13.webp";
import CourseFour from "../assets/img/PAUA-14.webp";
import CourseFive from "../assets/img/PAUA-15.webp";
import CourseSix from "../assets/img/PAUA-16.webp";
import CourseSeven from "../assets/img/PAUA-17.webp";
import CourseEight from "../assets/img/PAUA-18.webp";

import Excelsia from "../assets/img/excelsia.jpg";
import Aih from "../assets/img/logo-aih.png";
import Skyline from "../assets/img/logo-skyline.png";
import Ambridge from "../assets/img/logo-ambridge.png";
import Wentworth from "../assets/img/logo-wentworth.png";
import Acbi from "../assets/img/logo-acbi.png";
import Csu from "../assets/img/logo-csu.png";



const SearchCourses = () => {

    var settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 1,
        initialSlide: 0,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: false
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            }
        ]
    };

    return (
        <>
            <section className="popular-body section-padding searchCity" >
                <div className="container">
                    <div className="body-title">
                        <h1>SEARCH <span>Courses</span></h1>
                        <span className="title-border-btm"></span>
                    </div>
                    <div className="section-body searchCours-img">

                        <Slider {...settings} className="popularSlide slider">
                            <div className="slide">
                                <div className="explore-cardSC">
                                    <div className="exploreOverlaySC"></div>
                                    <img src={CourseOne} alt="PAUA-1" />
                                    <div className="card-rankSC">
                                        <span className="rankSC">AU $2925 <h6>per term</h6></span>
                                        <span className="rackCountrySC">SYD</span>
                                    </div>
                                    <div className="university-logo">
                                        <img src={Skyline} alt="logo-skyline" className="" />
                                    </div>
                                    <div className="explore-card-contentSC">
                                        <h4>Certificate III in Light Vehicle Mechanical Technology</h4>
                                        <span className="border-bottomcontentSC"></span>
                                        <p>Skyline International college</p>
                                        <div className="durationSC">
                                            <span className="durationClock"> <i className="far fa-clock"></i> 60 week</span>
                                            <span className="durationMore"><a href="http://sic.edu.au/course/aur30620-certificate-iii-in-light-vehicle-mechanical-technology/"><i className="fas fa-arrow-right"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="slide">
                                <div className="explore-cardSC">
                                    <div className="exploreOverlaySC"></div>
                                    <img src={CourseTwo} alt="cours-bcm.jpg" />
                                    <div className="card-rankSC">
                                        <span className="rankSC price-range"> AU $2925 <h6>per term</h6></span>
                                        <span className="rackCountrySCOrange">SYD</span>
                                    </div>
                                    <div className="university-logo">
                                        <img src={Skyline} alt="logo-skyline" className="" />
                                    </div>
                                    <div className="explore-card-contentSCOrange">
                                        <h4>Certificate IV in Automotive Mechanical Diagnosis </h4>
                                        <span className="border-bottomcontentSC"></span>
                                        <p>Skyline International college</p>
                                        <div className="durationSC">
                                            <span className="durationClock"> <i className="far fa-clock"></i> 60 week </span>
                                            <span className="durationMore"><a href="http://sic.edu.au/course/aur30620-certificate-iii-in-light-vehicle-mechanical-technology/"><i className="fas fa-arrow-right"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="slide">
                                <div className="explore-cardSC">
                                    <div className="exploreOverlaySC"></div>
                                    <img src={CourseThree} alt="cours-ab" />
                                    <div className="card-rankSC">
                                        <span className="rankSC">AU $1250<h6>per term</h6></span>
                                        <span className="rackCountrySC">SYD</span>
                                    </div>
                                    <div className="university-logo">
                                        <img src={Ambridge} alt="logo-ambridge" className="" />
                                    </div>
                                    <div className="explore-card-contentSC">
                                        <h4>Diploma of Business</h4>
                                        <span className="border-bottomcontentSC"></span>
                                        <p>Ambridge Institute</p>
                                        <div className="durationSC">
                                            <span className="durationClock"> <i className="far fa-clock"></i> 52 weeks</span>
                                            <span className="durationMore"><a href="https://www.ambridge.edu.au/diploma-of-business/"><i className="fas fa-arrow-right"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="slide">
                                <div className="explore-cardSC">
                                    <div className="exploreOverlaySC"></div>
                                    <img src={CourseFour} alt="cours-cadc" />
                                    <div className="card-rankSC">
                                        <span className="rankSC price-range">AU $1200 <h6>per term</h6></span>
                                        <span className="rackCountrySCOrange">SYD</span>
                                    </div>
                                    <div className="university-logo">
                                        <img src={Aih} alt="logo-ih" className="" />
                                    </div>
                                    <div className="explore-card-contentSCOrange">
                                        <h4>Diploma of Social Media Marketing</h4>
                                        <span className="border-bottomcontentSC"></span>
                                        <p>International House</p>
                                        <div className="durationSC">
                                            <span className="durationClock"> <i className="far fa-clock"></i> 6 weeks</span>
                                            <span className="durationMore"><a href="https://ihbc.edu.au/diploma-of-social-media-marketing/"><i className="fas fa-arrow-right"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="slide">
                                <div className="explore-cardSC">
                                    <div className="exploreOverlaySC"></div>
                                    <img src={CourseFive} alt="cours-med" />
                                    <div className="card-rankSC">
                                        <span className="rankSC">AU $40,000<h6>(2021 annual)</h6></span>
                                        <span className="rackCountrySC">SYD</span>
                                    </div>
                                    <div className="university-logo">
                                        <img src={Excelsia} alt="excelsia" className="" />
                                    </div>
                                    <div className="explore-card-contentSC">
                                        <h4>Master of Business (Research)</h4>
                                        <span className="border-bottomcontentSC"></span>
                                        <p>Excelsia College</p>
                                        <div className="durationSC">
                                            <span className="durationClock"> <i className="far fa-clock"></i> 2  Years  </span>
                                            <span className="durationMore"><a href="https://excelsia.edu.au/courses/business/master-of-business-research/"><i className="fas fa-arrow-right"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="slide">
                                <div className="explore-cardSC">
                                    <div className="exploreOverlaySC"></div>
                                    <img src={CourseSix} alt="cours-cadc" />
                                    <div className="card-rankSC">
                                        <span className="rankSC price-range">AU $22,000<h6>PER YEAR</h6></span>
                                        <span className="rackCountrySCOrange">SYD</span>
                                    </div>
                                    <div className="university-logo">
                                        <img src={Wentworth} alt="logo-wentworth" className="" />
                                    </div>
                                    <div className="explore-card-contentSCOrange">
                                        <h4>BACHELOR OF INTERACTIVE MEDIA</h4>
                                        <span className="border-bottomcontentSC"></span>
                                        <p>Wentworth Institute</p>
                                        <div className="durationSC">
                                            <span className="durationClock"> <i className="far fa-clock"></i> 3  Years  </span>
                                            <span className="durationMore"><a href="https://www.win.edu.au/undergraduate-courses/bachelor-of-interactive-media/"><i className="fas fa-arrow-right"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="slide">
                                <div className="explore-cardSC">
                                    <div className="exploreOverlaySC"></div>
                                    <img src={CourseSeven} alt="cours-med" />
                                    <div className="card-rankSC">
                                        <span className="rankSC">AU $1500<h6>per term</h6></span>
                                        <span className="rackCountrySC">SYD</span>
                                    </div>
                                    <div className="university-logo">
                                        <img src={Acbi} alt="logo-acbi.png" className="" />
                                    </div>
                                    <div className="explore-card-contentSC">
                                        <h4>Diploma of Sustainable Operations</h4>
                                        <span className="border-bottomcontentSC"></span>
                                        <p>Australian College of Business intelligence</p>
                                        <div className="durationSC">
                                            <span className="durationClock"> <i className="far fa-clock"></i> 78 weeks </span>
                                            <span className="durationMore"><a href="https://www.acbi.edu.au/mss50118-diploma-of-sustainable-operations"><i className="fas fa-arrow-right"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="slide">
                                <div className="explore-cardSC">
                                    <div className="exploreOverlaySC"></div>
                                    <img src={CourseEight} alt="cours-cadc" />
                                    <div className="card-rankSC">
                                        <span className="rankSC price-range">AU $33,216<h6>per year</h6></span>
                                        <span className="rackCountrySCOrange">SYD</span>
                                    </div>
                                    <div className="university-logo">
                                        <img src={Csu} alt="logo-csu" className="" />
                                    </div>
                                    <div className="explore-card-contentSCOrange">
                                        <h4>Master of Information Technology</h4>
                                        <span className="border-bottomcontentSC"></span>
                                        <p>Charles Sturt University</p>
                                        <div className="durationSC">
                                            <span className="durationClock"> <i className="far fa-clock"></i> 2  Years  </span>
                                            <span className="durationMore"><a href="https://www.csustudycentres.edu.au/courses/pg/master-it-16-subjects"><i className="fas fa-arrow-right"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Slider>

                        <div className="viewAll text-center">
                            <a href="# " className="ViewAll-btn">View All Courses</a>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}

export default SearchCourses
