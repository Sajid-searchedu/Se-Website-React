import React from 'react';
import Slider from 'react-slick';

import Ielts from "../assets/img/ielts.webp";
import Pte from "../assets/img/pte.webp";
import Naati from "../assets/img/naati.webp";

const SearchTests = () => {

    var settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 3,
        slidesToScroll: 1,
        initialSlide: 0,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: false
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    };
    return (
        <>
            <section className="popular-body section-padding" id="tests">
                <div className="container searchTests">
                    <div className="body-title">
                        <h1>SEARCH <span>Tests</span></h1>
                        <span className="title-border-btm"></span>
                    </div>
                    <div className="section-body search-test-img">

                        <Slider {...settings} className="TestSlide slider">
                            <div className="slide">
                                <div className="ieltsCard">
                                    <div className="ieltsOveraly"></div>
                                    <div className="ieltsCard-img">
                                        <img src={Ielts} alt="ielts" />
                                    </div>
                                    <div className="ieltsCard-content">
                                        <h4>IELTS</h4>
                                        <p>IELTS is the high-stakes English test for study, migration or work</p>
                                        <a href="# " className="viewCourse-btn">View More <i className="fas fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div className="slide">
                                <div className="ieltsCard">
                                    <div className="ieltsOveraly"></div>
                                    <div className="ieltsCard-img">
                                        <img src={Pte} alt="pte" />
                                    </div>
                                    <div className="ieltsCard-content">
                                        <h4>PTE</h4>
                                        <p>Unbiased English testing for study abroad and immigration</p>
                                        <a href="# " className="viewCourse-btn">View More <i className="fas fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div className="slide">
                                <div className="ieltsCard">
                                    <div className="ieltsOveraly"></div>
                                    <div className="ieltsCard-img">
                                        <img src={Naati} alt="ieletCard" />
                                    </div>
                                    <div className="ieltsCard-content">
                                        <h4>NAATI CCL</h4>
                                        <p>A way to Australian PR via a point-based visa application</p>
                                        <a href="# " className="viewCourse-btn">View More <i className="fas fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div className="slide">
                                <div className="ieltsCard">
                                    <div className="ieltsOveraly"></div>
                                    <div className="ieltsCard-img">
                                        <img src={Ielts} alt="ielts" />
                                    </div>
                                    <div className="ieltsCard-content">
                                        <h4>IELTS</h4>
                                        <p>IELTS is the high-stakes English test for study, migration or work</p>
                                        <a href="# " className="viewCourse-btn">View More <i className="fas fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>

                        </Slider>
                        <div className="viewAll text-center">
                            <a href="# " className="ViewAll-btn">View All Tests</a>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default SearchTests
