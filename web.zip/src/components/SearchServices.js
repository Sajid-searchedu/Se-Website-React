import React from 'react';
import University from "../assets/img/university.png";
import Visa from "../assets/img/visa.png";
import Application from "../assets/img/application.png";
import PreDeparture from "../assets/img/pre-departure.png";
import Accomodation from "../assets/img/accomodation.png";
import IeltsTest from "../assets/img/ielts-test.png";




const SearchServices = () => {
    return (
        <>
            <section className="search-services section-padding" id="services">
                <div className="search-services-overlay"></div>
                <div className="container">
                    <div className="search-services-title text-center">
                        <h1 className="clr-black">search <span> services</span></h1>
                        <span className="title-border-btm"></span>
                    </div>

                    <div className="row justify-content-center">
                        <div className="col-md-4">
                            <div className="search-service-card">
                                <img src={University} alt="university" className="img-fluid" />
                                <h5>Course & career Counselling</h5>
                                <p>We help internationals to get enrolled into the best possible career-oriented courses along with the selection of colleges and universities across Australia. We help them in their journey with the enrollment and application process.</p>
                                <a href=" ">View more </a>
                                <div className="circle-bg"></div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="search-service-card">
                                <img src={Visa} alt="visa" className="img-fluid" />
                                <h5>Visa application and Migration assistance</h5>
                                <p>Student visa, Temporary graduate visa (485 visa), General Skilled Migration (189 and 190 Visa), Skill Assessment Assistance, Employer Sponsored visa (186 and 187 visa), Partner Visa, Tourist Visa </p>
                                <a href=" ">View more </a>
                                <div className="circle-bg"></div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="search-service-card">
                                <img src={Application} alt="application" className="img-fluid" />
                                <h5>Health Insurance (OSHC, OVHC)</h5>
                                <p>We provide Health Insurance to various visa subclassName holders. Like Overseas Student Health Cover for students and Overseas Health Visitor Cover for Visitors such as Tourist visa holder, 485 visa holder etc.</p>
                                <a href=" ">View more </a>
                                <div className="circle-bg"></div>
                            </div>
                        </div>
                    </div>
                    <div className="row justify-content-center">
                        <div className="col-md-4">
                            <div className="search-service-card">
                                <img src={PreDeparture} alt="pre-departure" className="img-fluid" />
                                <h5>Scholarship application assistance</h5>
                                <p>Though it depends upon the universities in providing scholarship, we help students to get enrolled into the colleges/universities where the scholarship is available.</p>
                                <a href=" ">View more </a>
                                <div className="circle-bg"></div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="search-service-card">
                                <img src={Accomodation} alt="accomodation" className="img-fluid" />
                                <h5>Professional Year/ NAATI CCL assistance</h5>
                                <p>It is a job-ready programme for international students to experience a real Australian work environment. We are affiliated with various PY providers.</p>
                                <a href=" ">View more </a>
                                <div className="circle-bg"></div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="search-service-card">
                                <img src={IeltsTest} alt="ielts-test" className="img-fluid" />
                                <h5>IELTS / PTE Preparations</h5>
                                <p>We are the partner of Language Academy; they provide PTE and IELTS. So if you need any service we recommend them to Language Academy.</p>
                                <a href=" ">View more </a>
                                <div className="circle-bg"></div>
                            </div>
                        </div>
                    </div>


                </div>
            </section>
        </>
    )
}

export default SearchServices
