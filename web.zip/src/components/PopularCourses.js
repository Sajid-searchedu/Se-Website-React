import React from 'react';
import PcOne from "../assets/img/PAUA-1.webp";
import PcTwo from "../assets/img/PAUA-2.webp";
import PcThree from "../assets/img/PAUA-3.webp";
import PcFour from "../assets/img/PAUA-4.webp";
import PcFive from "../assets/img/PAUA-5.webp";
import PcSix from "../assets/img/PAUA-6.webp";
import PcSeven from "../assets/img/PAUA-7.webp";
import PcEight from "../assets/img/PAUA-8.webp";
import PcNine from "../assets/img/PAUA-9.webp";
import Excelsia from "../assets/img/excelsia.jpg";
import Aih from "../assets/img/logo-aih.png";
import Vu from "../assets/img/logo-vu.png";
import SwinEca from "../assets/img/logo-swin-eca.png";
import Holmes from "../assets/img/logo-holmes.png";


const PopularCourses = () => {
    return (
        <>
            <section className="popular-body section-padding" id="popularCourse" >
                <div className="container">
                    <div className="body-title">
                        <h1>POPULAR <span>Courses</span></h1>
                        <span className="title-border-btm"></span>
                    </div>
                    <div className="section-body popularCours-img">
                        <div className="testmonial-slide px-3 px-sm-5">
                            <div className="owl-carousel owl-theme">
                                <div className="item first prev">
                                    <div className="card border-0 card-property">
                                        <div className="explore-card">
                                            <div className="exploreOverlay"></div>
                                            <img src={PcOne} alt="cours-med" className="PC-img" />
                                            <div className="card-rank">
                                                <span className="rank ">AU$ 7500 <h6>PER SEM</h6></span>
                                                <span className="rackCountry rackCountry-blue">SYD</span>
                                            </div>

                                            <div className="explore-university-logo">
                                                <img src={Excelsia} alt="excelsia" className="img-fluid" />
                                            </div>
                                            <div className="explore-card-content explore-card-content-blue">
                                                <h4>Master of Business Administration</h4>
                                                <span className="border-bottomcontentSC"></span>
                                                <p>Excelsia College </p>
                                                <div className="durationSC">
                                                    <span className="durationClock"> <i className="far fa-clock"></i> 2  Years  </span>
                                                    <span className="durationMore"><a href="https://excelsia.edu.au/courses/business/master-of-business-administration/"><i className="fas fa-arrow-right"></i></a></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="item show">
                                    <div className="card border-0 card-property">
                                        <div className="explore-card">
                                            <div className="exploreOverlay"></div>
                                            <img src={PcTwo} alt="exploreCard" className="PC-img" />
                                            <div className="card-rank">
                                                <span className="rank price-range">AU $7,800 <h6>PER SEM</h6></span>
                                                <span className="rackCountry">SYD</span>
                                            </div>
                                            <div className="explore-university-logo">
                                                <img src={Excelsia} alt="excelsia" className="img-fluid" />
                                            </div>
                                            <div className="explore-card-content explore-card-content-orange">
                                                <h4>Bachelor of Early Childhood</h4>
                                                <span className="border-bottomcontentSC"></span>
                                                <p>Excelsia College</p>
                                                <div className="durationSC">
                                                    <span className="durationClock"> <i className="far fa-clock"></i> 4  Years  </span>
                                                    <span className="durationMore"><a href="https://excelsia.edu.au/courses/education/bachelor-of-early-childhood-education/"><i className="fas fa-arrow-right"></i></a></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="item next">
                                    <div className="card border-0 card-property">
                                        <div className="explore-card">
                                            <div className="exploreOverlay"></div>
                                            <img src={PcThree} alt="exploreCard" className="PC-img" />
                                            <div className="card-rank">
                                                <span className="rank">AU $10,260 <h6>PER SEM</h6></span>
                                                <span className="rackCountry rackCountry-blue">SYD</span>
                                            </div>
                                            <div className="explore-university-logo">
                                                <img src={Excelsia} alt="excelsia" className="img-fluid" />
                                            </div>
                                            <div className="explore-card-content explore-card-content-blue">
                                                <h4>Master of Social Work</h4>
                                                <span className="border-bottomcontentSC"></span>
                                                <p>Excelsia College</p>
                                                <div className="durationSC">
                                                    <span className="durationClock"> <i className="far fa-clock"></i> 2  Years  </span>
                                                    <span className="durationMore"><a href="https://excelsia.edu.au/courses/social-work/master-of-social-work/"><i className="fas fa-arrow-right"></i></a></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="item next">
                                    <div className="card border-0 card-property">
                                        <div className="explore-card">
                                            <div className="exploreOverlay"></div>
                                            <img src={PcFour} alt="cours-ab.jpg" className="PC-img" />
                                            <div className="card-rank">
                                                <span className="rank price-range">AU $6400 <h6>PER SEM</h6> </span>
                                                <span className="rackCountry">SYD</span>
                                            </div>
                                            <div className="explore-university-logo">
                                                <img src={Aih} alt="excelsia" className="img-fluid" />
                                            </div>
                                            <div className="explore-card-content explore-card-content-orange">
                                                <h4>Bachelor of Accounting</h4>
                                                <span className="border-bottomcontentSC"></span>
                                                <p>Australian Institute of Higher Education</p>
                                                <div className="durationSC">
                                                    <span className="durationClock"> <i className="far fa-clock"></i> 3  Years  </span>
                                                    <span className="durationMore"><a href="https://aih.nsw.edu.au/courses/bachelor-of-accounting/"><i className="fas fa-arrow-right"></i></a></span>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="item next">
                                    <div className="card border-0 card-property">
                                        <div className="explore-card">
                                            <div className="exploreOverlay"></div>
                                            <img src={PcFive} alt="PAUA" className="PC-img" />
                                            <div className="card-rank">
                                                <span className="rank">AU $6400 <h6>PER SEM</h6> </span>
                                                <span className="rackCountry rackCountry-blue">SYD</span>
                                            </div>
                                            <div className="explore-university-logo">
                                                <img src={Aih} alt="excelsia" className="img-fluid" />
                                            </div>
                                            <div className="explore-card-content explore-card-content-blue">
                                                <h4>Bachelor of Business Information Systems</h4>
                                                <span className="border-bottomcontentSC"></span>
                                                <p>Australian Institute of Higher Education</p>
                                                <div className="durationSC">
                                                    <span className="durationClock"> <i className="far fa-clock"></i> 3  Years  </span>
                                                    <span className="durationMore"><a href="https://aih.nsw.edu.au/courses/bachelor-of-business-information-systems/"><i className="fas fa-arrow-right"></i></a></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="item next">
                                    <div className="card border-0 card-property">
                                        <div className="explore-card">
                                            <div className="exploreOverlay"></div>
                                            <img src={PcSix} alt="PAUA" className="PC-img" />
                                            <div className="card-rank">
                                                <span className="rank price-range">AU $9064 <h6>PER SEM</h6> </span>
                                                <span className="rackCountry">SYD</span>
                                            </div>
                                            <div className="explore-scholarshipSC">
                                                <span>20% Scholarship <b>*</b></span>
                                            </div>
                                            <div className="explore-university-logo">
                                                <img src={Vu} alt="excelsia" className="img-fluid" />
                                            </div>
                                            <div className="explore-card-content explore-card-content-orange">
                                                <h4>Bachelor of IT</h4>
                                                <span className="border-bottomcontentSC"></span>
                                                <p>Victoria University Sydney</p>
                                                <div className="durationSC">
                                                    <span className="durationClock"> <i className="far fa-clock"></i> 3  Years  </span>
                                                    <span className="durationMore"><a href="https://www.vu.edu.au/vu-sydney/courses-at-vu-sydney/bachelor-of-information-technology"><i className="fas fa-arrow-right"></i></a></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="item next">
                                    <div className="card border-0 card-property">
                                        <div className="explore-card">
                                            <div className="exploreOverlay"></div>
                                            <img src={PcSeven} alt="PAUA" className="PC-img" />
                                            <div className="card-rank">
                                                <span className="rank">AU $12,600 <h6>PER SEM</h6> </span>
                                                <span className="rackCountry rackCountry-blue">SYD</span>
                                            </div>
                                            <div className="explore-university-logo">
                                                <img src={SwinEca} alt="logo-swin-eca" className="img-fluid" />
                                            </div>
                                            <div className="explore-card-content explore-card-content-blue">
                                                <h4>Master of Data Science</h4>
                                                <span className="border-bottomcontentSC"></span>
                                                <p>Swinburne University Sydney</p>
                                                <div className="durationSC">
                                                    <span className="durationClock"> <i className="far fa-clock"></i> 2  Years  </span>
                                                    <span className="durationMore"><a href="https://www.swinburne.edu.au/study/course/Master-of-Data-Science-MA-DATASC/international"><i className="fas fa-arrow-right"></i></a></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="item next">
                                    <div className="card border-0 card-property">
                                        <div className="explore-card">
                                            <div className="exploreOverlay"></div>
                                            <img src={PcEight} alt="PAUA" className="PC-img" />
                                            <div className="card-rank">
                                                <span className="rank price-range">AU $8400 <h6>PER SEM</h6> </span>
                                                <span className="rackCountry">MEL</span>
                                            </div>
                                            <div className="explore-scholarshipSC">
                                                <span>15% Scholarship <b>*</b></span>
                                            </div>
                                            <div className="explore-university-logo">
                                                <img src={Holmes} alt="logo-holmes" className="img-fluid" />
                                            </div>
                                            <div className="explore-card-content explore-card-content-orange">
                                                <h4>Master of Professional Accounting</h4>
                                                <span className="border-bottomcontentSC"></span>
                                                <p>Holmes Institute</p>
                                                <div className="durationSC">
                                                    <span className="durationClock"> <i className="far fa-clock"></i> 3 Trimesters  </span>
                                                    <span className="durationMore"><a href="https://www.holmes.edu.au/pages/schools-and-faculties/higher-education/courses/master-of-professional-accounting"><i className="fas fa-arrow-right"></i></a></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="item next">
                                    <div className="card border-0 card-property">
                                        <div className="explore-card">
                                            <div className="exploreOverlay"></div>
                                            <img src={PcNine} alt="PAUA" className="PC-img" />
                                            <div className="card-rank">
                                                <span className="rank">AU $8400 <h6>PER SEM</h6> </span>
                                                <span className="rackCountry rackCountry-blue">MEL</span>
                                            </div>
                                            <div className="explore-scholarshipSC">
                                                <span>15% Scholarship <b>*</b></span>
                                            </div>
                                            <div className="explore-university-logo">
                                                <img src={Holmes} alt="logo-holmes" className="img-fluid" />
                                            </div>
                                            <div className="explore-card-content explore-card-content-blue">
                                                <h4>Master of Business Administration </h4>
                                                <span className="border-bottomcontentSC"></span>
                                                <p>Holmes Institute</p>
                                                <div className="durationSC">
                                                    <span className="durationClock"> <i className="far fa-clock"></i> 3 Trimesters  </span>
                                                    <span className="durationMore"><a href="https://www.holmes.edu.au/pages/schools-and-faculties/higher-education/courses/master-of-business-administration"><i className="fas fa-arrow-right"></i></a></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </>
    )
}

export default PopularCourses
