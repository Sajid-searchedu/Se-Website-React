import React from 'react';
import BrandLogo from "../assets/img/SE-logo.webp";
import BrandLogoWhite from "../assets/img/SE-logo-white.webp";
import SearchIcon from "../assets/img/searchicon.webp";
import SigninBg from "../assets/img/signin-bg.png";


const Header = () => {
    return (
        <>
            <header className="header-section">
                <nav className="navbar navbar-expand-lg fixed-top" id="main_navbar">
                    <div className="container">

                        <a className="navbar-brand white-logo" href="# "> <img src={BrandLogoWhite} alt="Search Education" width="100%" /></a>
                        <a className="navbar-brand color-logo" href="index.html"> <img src={BrandLogo} alt="Search Education" width="100%" /></a>
                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"><i className="fa fa-bars" aria-hidden="true"></i></span>
                        </button>
                        <div className="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul className="navbar-nav ml-auto">
                                <li className="d-inline d-lg-none">
                                    <button data-toggle="collapse" data-target="#navbarSupportedContent" className="close float-right">&times;</button>
                                </li>

                                <li className="nav-item">
                                    <div className="search-course nav-search  ml-auto" data-toggle="modal" data-target="#SeSearchModal">
                                        <form>
                                            <div className="input-group">
                                                <input type="text" className="form-control border-0" placeholder="Search Courses, Country & More" />
                                                <div className="input-group-append">
                                                    <button className="btn btn-default" type="button">
                                                        <img src={SearchIcon} alt="search" />
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </li>

                                <li className="nav-item active">
                                    <a className="nav-link" href="index.html">Home <span className="sr-only">(current)</span></a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="aboutUs.html">ABOUT US</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="services.html">SERVICES</a>
                                </li>

                                <li className="nav-item dropdown dmenu">
                                    <a className="nav-link dropdown-toggle" href="get-visa.html" id="navbarDropdownMenuLink">
                                        Visas
                                    </a>
                                    <ul className="dropdown-menu sm-menu custom-arrow" aria-labelledby="navbarDropdownMenuLink"> <span className="custom-arrow-top"></span>
                                        <li><a className="dropdown-item" href="student-visa.html">Student Visa</a></li>
                                        <li className="dropdown-submenu  dmenu"><a className="dropdown-item dropdown-toggle" href="# ">Employer Sponsored Visas</a>
                                            <ul className="dropdown-menu sm-menu">
                                                <li><a className="dropdown-item" href="Employer-visa.html">Employer Visa SUBclassName= 482</a></li>
                                                <li><a className="dropdown-item" href="Employer-visa494.html">Employer Visa SUBclassName= 494</a></li>
                                                <li> <a className="dropdown-item border-none" href="Employer-visa186.html">Employer Visa SUBclassName= 186</a></li>
                                            </ul>
                                        </li>
                                        <li className="dropdown-submenu dmenu"><a className="dropdown-item border-none dropdown-toggle" href="# ">General Skilled Migration</a>
                                            <ul className="dropdown-menu sm-menu">
                                                <li><a className="dropdown-item" href="family-sponsored491.html">FAMILY- SPONSORED VISA SUBclassName= 491</a></li>
                                                <li><a className="dropdown-item" href="skilled-work-regional491.html">SKILLED WORK REGIONAL VISA SUBclassName= 491</a></li>
                                                <li><a className="dropdown-item" href="general-skilled-migration.html">GENERAL SKILLED MIGRATION SUBclassName= 190</a></li>
                                                <li><a className="dropdown-item border-none" href="skilled-independent-visa189.html">Skilled Independent Visa SUBclassName= 189</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>

                                <li className="nav-item">
                                    <a className="nav-link" href="career.html">Career</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="contactUs.html">CONTACT US</a>
                                </li>
                                <li className="nav-item">
                                    <button className="btn get-call my-2 my-sm-0" id="SignIn" data-toggle="modal" data-target="#myModal"><a href="# " className="signNow"> LogIn</a> / <a href="# " className=" SignUp ">SignUp</a></button>
                                </li>
                                <li className="nav-item dropdown">
                                    <a href="# " className="nav-link dropdown-toggle" data-toggle="dropdown"> Ankush </a>
                                    <div className="dropdown-menu dropdown-menu-right">
                                        <a href="# " className="dropdown-item"><i className="fa fa-user-circle" aria-hidden="true"></i> Account</a>
                                        <a href="# " className="dropdown-item"><i className="fa fa-key" aria-hidden="true"></i> Change Password</a>
                                        <a href="# " className="dropdown-item"><i className="fas fa-sign-out-alt"></i> Logout</a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>


                <div id="myModal" className="modal">
                    <div className="modal-content">
                        <span className="closed" data-dismiss="modal" aria-label="Close">&times;</span>
                        <div className="sign-modal">
                            <div className="row">
                                <div className="col-md-6">
                                    <div className="sign-in modal-user"><br /><br />
                                        <h4 className="text-center">Sign In</h4>
                                        <form>
                                            <div className="form-group">
                                                <input type="text" className="form-control" placeholder=" User name" id="user" />
                                            </div>
                                            <div className="form-group">
                                                <input type="password" className="form-control" placeholder="Password" id="pwd" />
                                            </div>
                                            <div className="custom-control custom-checkbox">
                                                <label> <a href="# ">Forgot your password?</a></label>
                                            </div>
                                            <div className=" sign-userBtn text-center">
                                                <a href=' #' type="button" className="btn-signin text-center">Sign in</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div className="col-md-6">
                                    <div className="sign-banner text-center">
                                        <img src={SigninBg} alt="signin-bg" className="img-fluid" />
                                        <div className="sign-banner-content">
                                            <h4 className="text-center">Hello, Friend!</h4>
                                            <p>Enter your details and <br /> Start your journey with us</p>
                                            <div className=" sign-userBtn text-center">
                                                <a href=' #' type="button" className="btn-signup SignUp text-center">Sign Up</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="signUp-modal">
                            <div className="row">
                                <div className="col-md-6">
                                    <div className="sign-banner text-center">
                                        <img src={SigninBg} alt="signin-bg" className="img-fluid" />
                                        <div className="sign-banner-content">
                                            <h4 className="text-center">Welcome Back!</h4>
                                            <p>To keep connected please login <br /> using your personal info</p>
                                            <div className=" sign-userBtn text-center">
                                                <a href=' #' type="button" className="btn-signin signNow text-center">Sign in</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-6">
                                    <div className="sign-in modal-user">
                                        <h4 className="text-center">Create Account</h4>
                                        <form>
                                            <div className="form-group">
                                                <input type="text" className="form-control" placeholder=" User name" id="user-up" />
                                            </div>
                                            <div className="form-group">
                                                <input type="email" className="form-control" placeholder=" Email" id="email" />
                                            </div>
                                            <div className="form-group">
                                                <input type="number" className="form-control" placeholder=" Phone Number" id="phNumber" />
                                            </div>
                                            <div className="form-group">
                                                <input type="password" className="form-control" placeholder="Password" id="pwd-up" />
                                            </div>
                                            <div className=" sign-userBtn text-center">
                                                <a href=' #' type="button" className="btn-signin text-center">Sign up</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>

            </header>


        </>
    )
}

export default Header
