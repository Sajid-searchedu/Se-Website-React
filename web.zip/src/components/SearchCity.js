import React from 'react';

import Slider from "react-slick";

import CityOne from "../assets/img/Cities-03.webp";
import CityTwo from "../assets/img/Cities-04.webp";
import CityThree from "../assets/img/Cities-05.webp";
import CityFour from "../assets/img/Cities-06.webp";
import CityFive from "../assets/img/Cities-07.webp";
import CitySix from "../assets/img/Cities-10.webp";
import CitySeven from "../assets/img/canberra.webp";
import CityEight from "../assets/img/Cities-08.webp";

const SearchCity = () => {

    var settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 5,
        slidesToScroll: 1,
        initialSlide: 0,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: false
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            }
        ]
    };
    return (
        <>
            <div className="searchCity">
                <div className="body-title">
                    <h1>SEARCH <span>City</span></h1>
                    <span className="title-border-btm"></span>
                </div>
                <div className='container countries-body'>
                    <Slider {...settings} className="countrySlide slider">
                        <div className="slide">
                            <div className="countries-card img-hover-zoom">

                                <div className="content"> <a href="# ">
                                    <div className="content-overlay"></div>  <div className="body-overlay"></div> <img className="content-image " alt='search city' src={CityOne} />
                                    <div className="studyCard-content">
                                        <p>Study in</p>
                                        <h4>Melbourne</h4>
                                    </div>
                                    <div className="content-details fadeIn-bottom">
                                        <h3 className="content-title">Voted second most liveable city for the sixth year in a row, Economist’s global liveability survey</h3>
                                    </div>
                                </a> </div>
                            </div>
                        </div>

                        <div className="slide">
                            <div className="countries-card img-hover-zoom">
                                <div className="content"> <a href="# ">
                                    <div className="content-overlay"></div>  <div className="body-overlay"></div> <img className="content-image" alt='search city' src={CityTwo} />
                                    <div className="studyCard-content">
                                        <p>Study in</p>
                                        <h4>Sydney</h4>
                                    </div>
                                    <div className="content-details fadeIn-bottom">
                                        <h3 className="content-title">Home to the oldest university in Australia (The University of Sydney), the city has rich history of academic excellence.</h3>
                                    </div>
                                </a> </div>
                            </div>
                        </div>

                        <div className="slide">
                            <div className="countries-card img-hover-zoom">
                                <div className="content"> <a href="# ">
                                    <div className="content-overlay"></div>  <div className="body-overlay"></div> <img className="content-image" alt='search city' src={CityThree} />
                                    <div className="studyCard-content">
                                        <p>Study in</p>
                                        <h4>Brisbane</h4>
                                    </div>
                                    <div className="content-details fadeIn-bottom">
                                        <h3 className="content-title">Welcomes approximately 50,000 international students each year, because of the lively and multicultural lifestyle.</h3>
                                    </div>
                                </a> </div>
                            </div>
                        </div>

                        <div className="slide">
                            <div className="countries-card img-hover-zoom">
                                <div className="content"> <a href="# ">
                                    <div className="content-overlay"></div>  <div className="body-overlay"></div> <img className="content-image" alt='search city' src={CityFour} />
                                    <div className="studyCard-content">
                                        <p>Study in</p>
                                        <h4>Adelaide</h4>
                                    </div>
                                    <div className="content-details fadeIn-bottom">
                                        <h3 className="content-title">The city designed for life. Over 40,000 students from 130 countries choose to study, live and work in Adelaide. </h3>
                                    </div>
                                </a> </div>
                            </div>
                        </div>

                        <div className="slide">
                            <div className="countries-card img-hover-zoom">
                                <div className="content"> <a href="# ">
                                    <div className="content-overlay"></div>  <div className="body-overlay"></div> <img className="content-image" alt='search city' src={CityFive} />
                                    <div className="studyCard-content">
                                        <p>Study in</p>
                                        <h4>Perth</h4>
                                    </div>
                                    <div className="content-details fadeIn-bottom">
                                        <h3 className="content-title">In any given year, Perth attracts over 42,000 student enrolments from over 140 countries.</h3>
                                    </div>
                                </a> </div>
                            </div>
                        </div>

                        <div className="slide">
                            <div className="countries-card img-hover-zoom">
                                <div className="content"> <a href="# ">
                                    <div className="content-overlay"></div>  <div className="body-overlay"></div> <img className="content-image" alt='search city' src={CitySix} />
                                    <div className="studyCard-content">
                                        <p>Study in</p>
                                        <h4>Hobart</h4>
                                    </div>
                                    <div className="content-details fadeIn-bottom">
                                        <h3 className="content-title">Discover Tasmania's rich natural beauty in the capital city.</h3>
                                    </div>
                                </a> </div>
                            </div>
                        </div>
                        <div className="slide">
                            <div className="countries-card img-hover-zoom">
                                <div className="content"> <a href="# ">
                                    <div className="content-overlay"></div>  <div className="body-overlay"></div> <img className="content-image" alt='search city' src={CitySeven} />
                                    <div className="studyCard-content">
                                        <p>Study in</p>
                                        <h4>CANBERRA</h4>
                                    </div>
                                    <div className="content-details fadeIn-bottom">
                                        <h3 className="content-title">Discover educational institutions and world-className research centres in the national capital of Australia.</h3>
                                    </div>
                                </a> </div>
                            </div>
                        </div>
                        <div className="slide">
                            <div className="countries-card img-hover-zoom">
                                <div className="content"> <a href="# ">
                                    <div className="content-overlay"></div>  <div className="body-overlay"></div> <img className="content-image" alt='search city' src={CityEight} />
                                    <div className="studyCard-content">
                                        <p>Study in</p>
                                        <h4>DARWIN</h4>
                                    </div>
                                    <div className="content-details fadeIn-bottom">
                                        <h3 className="content-title">Explore life in this vibrant and multi-cultural city.</h3>
                                    </div>
                                </a> </div>
                            </div>
                        </div>

                    </Slider>
                </div>
            </div>
        </>
    )
}



export default SearchCity
