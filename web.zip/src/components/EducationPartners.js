import React from 'react';


const EducationPartners = () => {
    return (
        <>
            <section className="section-padding education-partner">
                <div className="container">
                    <div className="body-title">
                        <h1>Education  <span>Partners</span></h1>
                        <span className="title-border-btm"></span>
                    </div>
                    <div className="section-body pb-5 pb-xs-0">
                        <div id="carouselParnerLogo" className="carousel slide" data-ride="carousel">
                            <div className="carousel-inner">
                                <div className="carousel-item  active">
                                    <div className="row">
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Deakin.png" alt="Deakin" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/university-FOR-THE-CREATIVE-ARTS.jpg" alt="university-FOR-THE-CREATIVE-ARTS" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Bath-spa.jpg" alt="Bath-spa" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Mount-St-Vincent-University.jpg" alt="Mount-St-Vincent-University" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/heriot-watt.jpg" alt="heriot-watt" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/eastern-michigan.png" alt="eastern-michigan" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/University-of-Canada-West.png" alt="University-of-Canada-West" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/griffith.png" alt="griffith" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Selkirk.svg" alt="Selkirk" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Algoma-University.jpg" alt="Algoma-University" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/james_cook_logo.png" alt="james_cook" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Southern-Cross-University.png" alt="Southern-Cross-University" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/maynooth-logo.png" alt="maynooth" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/dcu-logo.jpeg" alt="dcu" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/The-Hotel-School-Southern-Cross-University.jpg" alt="The-Hotel-School-Southern-Cross-University" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/CCT.jpg" alt="CCT" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Yorkville-University.png" alt="Yorkville-University" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/nlc-logo.png" alt="nlc-logo" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Trebas-Institute.jpg" alt="Trebas-Institute" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/aaps_logo.jpg" alt="aaps University" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/atmc.jpg" alt="atmc" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Canberra-logo.jpg" alt="Canberra-logo" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/kaplan.png" alt="kaplan" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/lyit_logo.png" alt="lyit_logo" className="img-fluid" />
                                            </div>
                                        </div>


                                    </div>
                                </div>


                                <div className="carousel-item">
                                    <div className="row">

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Le-cordon-bleu.jpg" alt="Le-cordon-bleu" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Study-Group.jpg" alt="Study-Group" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Trebas-Institute.jpg" alt="Trebas-Institute" className="img-fluid" />
                                            </div>
                                        </div>


                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/TAFE-NSW.png" alt="TAFE-NSW" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Toronto-Film-School.png" alt="Toronto-Film-School" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/dbs-logo.png" alt="dbs-logo" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/cqu-logo.png" alt="cqu" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/nsw-tafe-logo.png" alt="nsw-tafe" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/aim-logo.png" alt="aim" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/STU-logo.png" alt="STU" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-4 col-md-4 col-8">
                                            <div className="education-partner-logo ecaSwin-logo">
                                                <img src="assets/img/eca-swinburne-logo.jpg" alt="eca-swinburne" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/victoria-logo.png" alt="victoria" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/excelsia-logo.jpg" alt="excelsia" className="img-fluid" />
                                            </div>
                                        </div>


                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/itsligo-logo.jpg" alt="itsligo" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-4 col-md-4 col-8">
                                            <div className="education-partner-logo Charles-logo">
                                                <img src="assets/img/charles-sturt-logo.png" alt="charles-sturt" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/wentworth-logo.png" alt="wentworth" className="img-fluid" />
                                            </div>
                                        </div>



                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/apic-logo.png" alt="apic" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/queensford-logo.jpeg" alt="queensford" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/dublin-logo.jpg" alt="dublin" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/macallan-logo.jpg" alt="macallan" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/navitas.png" alt="navitas" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Gordon-College.jpg" alt="Gordon-College" className="img-fluid" />
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div className="carousel-item">
                                    <div className="row">
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/IBAT-College-Dublin.jpg" alt="IBAT-College-Dublin" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/IIBIT-logo.jpg" alt="IIBIT-logo" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/International-college-of-management.jpg" alt="International-college-of-management" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/istituto-marangoni.jpg" alt="istituto-marangoni" className="img-fluid" />
                                            </div>
                                        </div>


                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/australis-logo.png" alt="australis" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/ahb-logo.jpg" alt="ahb-logo" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/ih-logo.png" alt="ih-logo" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/australian-ins-logo.jpeg" alt="australian-ins" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/skyline-logo.png" alt="skyline" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/lead-logo.png" alt="lead" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/ambridge-logo.png" alt="ambridge" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/alg-logo.png" alt="alg" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/holmes-logo.png" alt="holmes" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/educo-logo.png" alt="educo" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/college-of-the-Rockies.png" alt="college-of-the-Rockies" className="img-fluid" />
                                            </div>
                                        </div>


                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/LaSalle-College.png" alt="LaSalle-College" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/St-Michel-College.png" alt="St-Michel-College" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/ACSENDA-COLLEGE.jpg" alt="ACSENDA-COLLEGE" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Albright-college.jpg" alt="Albright-college" className="img-fluid" />
                                            </div>
                                        </div>

                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/American-College-Dublin.jpg" alt="American-College-Dublin" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/Federation-University-of-Australia.png" alt="Federation-University-of-Australia" className="img-fluid" />
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-4">
                                            <div className="education-partner-logo">
                                                <img src="assets/img/stanley-logo.png" alt="stanley-logo" className="img-fluid" />
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <a className="carousel-control-prev" href="#carouselParnerLogo" role="button" data-slide="prev">
                                <i className="fa-2x fa fa-angle-left" aria-hidden="true"></i>
                                <span className="sr-only">Previous</span>
                            </a>
                            <a className="carousel-control-next" href="#carouselParnerLogo" role="button" data-slide="next">
                                <i className="fa-2x fa fa-angle-right" aria-hidden="true"></i>
                                <span className="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}

export default EducationPartners
