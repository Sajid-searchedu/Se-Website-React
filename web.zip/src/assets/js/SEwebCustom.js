

// -------------heaader-changes------------------

 // $(document).ready(function(){
 //      $(window).scroll(function() { 
 //        if ($(document).scrollTop() > 50) {
 //          $(".navbar").css("background-color", "#fff");
 //          $(".navbar").css("box-shadow", "0 2px 5px 0 rgba(0,0,0,0.16), 0 2px 10px 0 rgba(0,0,0,0.12)");
 //          $(".navbar a").css("color" , "#23233e");
 //        } else {
 //          $(".navbar").css("background-color", "transparent");
 //          $(".navbar a").css("color" , "#fff"); 
 //          $(".navbar").css("box-shadow", "none");
 //        }
 //      });
 //    });


 // -------------#main_navbar------------------

   $(function () {
            $('#main_navbar').bootnavbar();
        });

 // -------------sub-menu-------------------

  $(document).ready(function () {
$('.fixed-top .dmenu').hover(function () {
        $(this).find('.sm-menu').first().stop(true, true).slideDown(150);
    }, function () {
        $(this).find('.sm-menu').first().stop(true, true).slideUp(105)
    });
});

// -------------search-bar-on-scroll------------------

 $(document).ready(function(){
      $(window).scroll(function() { 
        if ($(document).scrollTop() > 310) {
          $(".banner-search").css("display", "none");
          $(".DreamCourse").css("display", "none");
          $(".nav-search").css("display", "block");
         
        } else {
          $(".banner-search").css("display", "block");
          $(".DreamCourse").css("display", "flex");
          $(".nav-search").css("display", "none");
         
        }
      });
    });

// -------------change-logo-on-scroll------------------

   // $(document).ready(function(){
   //    $(window).scroll(function() { 
   //      if ($(document).scrollTop() > 50) {
   //        $(".white-logo").css("display", "none");
   //        $(".color-logo").css("display", "block");
   //        $(".fa-bars").css("color", '#f26524');
         
   //      } else {
   //        $(".white-logo").css("display", "block");
   //        $(".color-logo").css("display", "none");
   //        $(".fa-bars").css("color", '#fff');
         
   //      }
   //    });
   //  });

// -------------scroll-go-top-on-scroll------------------

 $(window).scroll(function() {
    if ($(this).scrollTop() > 90 ) {
        $('.scrolltop:hidden').stop(true, true).fadeIn();
    } else {
        $('.scrolltop').stop(true, true).fadeOut();
    }
});
$(function(){$(".scroll").click(function(){$("html,body").animate({scrollTop:$(".thetop").offset().top},"2000");return false})});


// ------------myModal-signIN------------------

var modal = document.getElementById("myModal");
var btn = document.getElementById("SignIn");
var span = document.getElementsByClassName("closed")[0];
btn.onclick = function() {
  modal.style.display = "block";
}
span.onclick = function() {
  modal.style.display = "none";
}
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};


// ------------myModal-signUp-modal-----------------

  $(document).ready(function(){
    $(".SignUp").click(function(){
      // $(".signUp-modal").show();
      $(".signUp-modal").fadeIn();
     $(".sign-modal").hide();
      $(".closed").css("color", "#25263E");
    });
  });
    $(document).ready(function(){
    $(".signNow").click(function(){
      $(".signUp-modal").hide();
     // $(".sign-modal").show();
      $(".sign-modal").fadeIn();
      $(".closed").css("color", "#fff");
    });
  });


// -------------countdown-------------------

  $({ Counter: 0 }).animate({
  Counter: $('.countDown').text()
}, {
  duration: 1000,
  easing: 'swing',
  step: function() {
    $('.countDown').text(Math.ceil(this.Counter));
  }
});

    $({ Counter: 0 }).animate({
  Counter: $('.countDown1').text()
}, {
  duration: 1000,
  easing: 'swing',
  step: function() {
    $('.countDown1').text(Math.ceil(this.Counter));
  }
});
      $({ Counter: 0 }).animate({
  Counter: $('.countDown2').text()
}, {
  duration: 1000,
  easing: 'swing',
  step: function() {
    $('.countDown2').text(Math.ceil(this.Counter));
  }
});


// -------------filter-span-------------------

   $(document).ready(function(){
    $(".filter-span").click(function(){
  $(".hidden-search").toggle();
   $(this).find('i').toggleClass('fas fa-sort-up fas fa-sort-down')
  });
});


// -------------Video-modal-------------------

  $(document).ready(function() {
var $videoSrc;  
$('.video-btn').click(function() {
    $videoSrc = $(this).data( "src" );
});
console.log($videoSrc);

$('#myModal2').on('shown.bs.modal', function (e) {
$("#video").attr('src',$videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0" ); 
})
  
$('#myModal2').on('hide.bs.modal', function (e) {
    $("#video").attr('src',$videoSrc); 
});
    
});


// ------------Country-state-dropdon-------------------

  populateCountries("country", "state"); 


// ------------instagramFeed------------------- 
   // (function($){
   //      $(window).on('load', function(){
   //          $.instagramFeed({
   //              'username': 'searchedu',
   //              'container': "#instagram-profiles-aus",
   //              'display_profile': false,
   //              'display_biography': false,
   //              'display_gallery': true,
   //              'display_captions': false,
   //              'callback': null,
   //              'styling': true,
   //              'items': 5,
   //              'items_per_row': 5,
   //              'margin': 1,
   //              'lazy_load': true,
   //              'on_error': console.error
   //          });
   //      });
   //  })(jQuery);



// -----------All-SearchCountrySlide----------------- 


  $(document).ready(function(){
    $('.SearchCountrySlide').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2500,
        arrows: true,
        dots: false,
        pauseOnHover: true,
        responsive: [{
            breakpoint: 768,
            settings: {
                slidesToShow: 3
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 2
            }
        }]
    });
});


  $(document).ready(function(){
    $('.popularSlide').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2500,
        arrows: true,
        dots: false,
        pauseOnHover: true,
        responsive: [{
            breakpoint: 992,
            settings: {
                slidesToShow: 3
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 2
            }
        }]
    });
});


  $(document).ready(function(){
    $('.countrySlide').slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2500,
        arrows: true,
        dots: false,
        pauseOnHover: true,
        responsive: [{
            breakpoint: 992,
            settings: {
                slidesToShow: 3
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 2
            }
        }]
    });
});


  $(document).ready(function(){
    $('.TestSlide').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2500,
        arrows: true,
        dots: false,
        pauseOnHover: true,
        responsive: [{
            breakpoint: 992,
            settings: {
                slidesToShow: 2
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 1
            }
        }]
    });
});


  $(document).ready(function(){
    $('.partner-logos').slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: true,
        dots: false,
        pauseOnHover: true,
        responsive: [{
            breakpoint: 768,
            settings: {
                slidesToShow: 3
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 2
            }
        }]
    });
});


  $(document).ready(function(){
    $('.countrySlide').slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2500,
        arrows: true,
        dots: false,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 992,
            settings: {
                slidesToShow: 3
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 2
            }
        }]
    });
});





  $(document).ready(function(){
    $('.NewCourseSlide').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2500,
        arrows: true,
        dots: false,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 992,
            settings: {
                slidesToShow: 2
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 1
            }
        }]
    });
});




  $(document).ready(function(){
    $('.SignleCourseSlide').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2500,
        arrows: true,
        dots: false,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 992,
            settings: {
                slidesToShow: 1
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 1
            }
        }]
    });
});


    $(document).ready(function(){
    $('.PopularMiniSlide').slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        rows: 2,
        autoplay: true,
        autoplaySpeed: 2500,
        arrows: true,
        dots: false,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 992,
            settings: {
                slidesToShow: 3
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 1
            }
        }]
    });
});



// ------------tooltip-----------------

 $(function () {
  $('[data-toggle="tooltip"]').tooltip()
});


// ------------accordion-dropdown-icon-change-----------------

     $(document).ready(function(){
        $(".collapse.show").each(function(){
          $(this).prev(".card-header").find(".fa").addClass("fa-angle-down").removeClass("fa-angle-right");
        });
        
        $(".collapse").on('show.bs.collapse', function(){
          $(this).prev(".card-header").find(".fa").removeClass("fa-angle-right").addClass("fa-angle-down");
        }).on('hide.bs.collapse', function(){
          $(this).prev(".card-header").find(".fa").removeClass("fa-angle-down").addClass("fa-angle-right");
        });
    }); 



    $(document).ready(function(){
    $(".filter-span").click(function(){
  $(".hidden-search").toggle();
   $(this).find('i').toggleClass('fas fa-sort-up fas fa-sort-down')
  });
});




// ------------Course-description---------------


$(document).ready(function(){
  $(".comapre-btn").click(function(){
    $(".compare-shortlist").slideToggle("slow");
  });
});



  $('.wishlist').click(function(){
  $(this).toggleClass('clicked');
});


  


