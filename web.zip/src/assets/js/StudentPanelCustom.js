 

// ----------Edit-profile-tabs-------------------------

 function formTabControl(){
  var i, items = $('#profileForm .nav-link'), pane = $('#profileForm .tab-pane');
  // next
  $('.nexttab').on('click', function(){
      for(i = 0; i < items.length; i++){
          if($(items[i]).hasClass('active') == true){
              break;
          }
      }
      if(i < items.length - 1){
          // for tab
          $(items[i]).removeClass('active');
          $(items[i+1]).addClass('active');
          // for pane
          $(pane[i]).removeClass('show active');
          $(pane[i+1]).addClass('show active');
      }

  });
  // Prev
  $('.prevtab').on('click', function(){
      for(i = 0; i < items.length; i++){
          if($(items[i]).hasClass('active') == true){
              break;
          }
      }
      if(i != 0){
          // for tab
          $(items[i]).removeClass('active');
          $(items[i-1]).addClass('active');
          // for pane
          $(pane[i]).removeClass('show active');
          $(pane[i-1]).addClass('show active');
      }
  });
}
formTabControl();


// ----------My-profile-collapse-------------------------

 $(document).ready(function() {
    $(".collapse.show").each(function() {
      $(this).prev(".card-header").find(".fa").addClass("fa-angle-down").removeClass("fa-angle-right");
    });
    $(".collapse").on('show.bs.collapse', function() {
      $(this).prev(".card-header").find(".fa").removeClass("fa-angle-right").addClass("fa-angle-down");
    }).on('hide.bs.collapse', function() {
      $(this).prev(".card-header").find(".fa").removeClass("fa-angle-down").addClass("fa-angle-right");
    });
  });


// ----------Student-profile-file-row-add-remove-------------------------

  $(document).ready(function() {
  $(".delete").hide();
  //addWorkExperience
  $("#addWorkExperience").click(function(e) {
    $(".delete").fadeIn("1500");
    $("#WorkExperience").append(
      '<div class="form-group"><input type="file" class="next-attached" id="WorkExperienceMore" /> </div>'
    );
  });

   //AddRecommendations
  $("#AddRecommendations").click(function(e) {
    $(".delete").fadeIn("1500");
    $("#recommendations").append(
      '<div class="form-group"><input type="file" class="next-attached" id="recommendationsMore" /><span class="attachedTitle">attached <i class="far fa-times-circle"></i> ,</span> </div>'
    );
  });

  $("body").on("click", ".delete", function(e) {
    $(".next-attached").last().remove();
     $(".attachedTitle").last().remove();
  });
});


$(".attachedTitle").click(function(){
   $(this).remove();
});

  


// ----------My-Application-tab-------------------------

 function myApplicationControl(){
  var i, items = $('#myApplication .nav-link'), pane = $('#myApplication .tab-pane');
  // next
  $('.nexttab').on('click', function(){
      for(i = 0; i < items.length; i++){
          if($(items[i]).hasClass('active') == true){
              break;
          }
      }
      if(i < items.length - 1){
          // for tab
          $(items[i]).removeClass('active');
          $(items[i+1]).addClass('active');
          // for pane
          $(pane[i]).removeClass('show active');
          $(pane[i+1]).addClass('show active');
      }

  });
  // Prev
  $('.prevtab').on('click', function(){
      for(i = 0; i < items.length; i++){
          if($(items[i]).hasClass('active') == true){
              break;
          }
      }
      if(i != 0){
          // for tab
          $(items[i]).removeClass('active');
          $(items[i-1]).addClass('active');
          // for pane
          $(pane[i]).removeClass('show active');
          $(pane[i-1]).addClass('show active');
      }
  });
}
myApplicationControl();


 $('#showSucsess').click(function(e) {
  e.preventDefault();
  alert('THANK YOU! We have received your application. Our Conseler will contact you as soon as possilbe for the update');
  location.href = "dashboard.html";
});


// -----------sidebar--------------------------

function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}


$(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });



// -----------notification-toogle--------------------------


// $(document).ready(function(){
//   $(".notificationPopup").click(function(){
//     $(".notification-popup").slideToggle("slow");
//   });
// });


$(document).ready(function(){
    $('.notificationPopup').click(function(event){
        event.stopPropagation();
         $(".notification-popup").slideToggle("slow");
         $(".account-seeting-popup").hide();
    });
    $(".notification-popup").on("click", function (event) {
        event.stopPropagation();
    });
});

$(document).on("click", function () {
    $(".notification-popup").hide();
});


// -----------accountPopup-toogle--------------------------


// $(document).ready(function(){
//   $(".accountPopup").click(function(){
//     $(".account-seeting-popup").slideToggle("slow");
//   });
// });


// $(document).ready(function(){
//     $('.accountPopup').click(function(event){
//         event.stopPropagation();
//          $(".account-seeting-popup").slideToggle("slow");
//           $(".notification-popup").hide();
//     });
//     $(".account-seeting-popup").on("click", function (event) {
//         event.stopPropagation();
//     });
// });

// $(document).on("click", function () {
//     $(".account-seeting-popup").hide();
// });



$(document).ready(function(){
    $('.account-top-user').hover(function(event){
        event.stopPropagation();
         $(".account-seeting-popup").slideDown();
          $(".notification-popup").hide();
    });
    // $(".account-seeting-popup").on("click", function (event) {
    //     event.stopPropagation();
    // });
    $(".account-seeting-popup").on("mouseleave", function (event) {
        event.stopPropagation();
        $(".account-seeting-popup").hide();
    });
});

$(document).on("click", function () {
    $(".account-seeting-popup").hide();
});





// -----------shortlist-course--------------------------

  $('.closeAlert').click(function() {
    return confirm('Are You Sure ?')
  });




// -----------Search-course---------------------------


$('.show-filter-btn').click(function() {
 $('.mob-filter').slideToggle();
});



  $('.wishlist').click(function(){
  $(this).toggleClass('clicked');
});

    $('.select ul li.option').click(function() {
    $(this).siblings().addBack().children().remove();
    var a = $(this).siblings().toggle();
    $(this).parent().prepend(this);
  });




// -----------compare-course-td-content-remove--------------------------

  $('.delCol1').click(function(e){
   $('td .tdCol1').remove();
});

$('.delCol2').click(function(e){
   $('td .tdCol2').remove();
});

$('.delCol3').click(function(e){
   $('td .tdCol3').remove();
});

$('.delCol4').click(function(e){
   $('td .tdCol4').remove();
});


// -----------feedback-review-star--------------------------

  $('.fa-star').click(function(){
  $(this).toggleClass('clicked');
});


// -----------shortlistedCourse-tr-remove--------------------------

$(document).ready(function(){
 $("#shortlistedCourse").on('click','.btnDelete',function(){
       $(this).closest('tr').remove();
     });
});




// ------------------dashboard-sidebar---------------------

   let sidebar = document.querySelector(".SeSidebarSecond");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
};


   if (window.matchMedia('(max-width: 600px)').matches)
    {
       $('.sidebarBtn').click(function(e){
   $('.seLogoreflet').toggle();
});
    };



//---------------------only-4-list-show-------------------------------

  var list = $('#myNotificationList .chat_list:gt(3)');
list.hide();

  var listNotify = $('#myNotifiyList li:gt(4)');
listNotify.hide();

