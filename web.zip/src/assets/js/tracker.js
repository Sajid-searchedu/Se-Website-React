


      $(document).ready(function(){
   
        $('.track-1').on('click', function(){
            $('.track-1 .check').hide();
             $(this).addClass('track-active');
             $('.track-1 .check').show();
             $('.track-main-1 .tack-default').removeClass('track-active');
             $('.track-main-2 .tack-default').removeClass('track-active');
             $('.track-main-2 .track-2').removeClass('track-active');
             $('.track-main-3 .track-3').removeClass('track-active');
             $('.track-2 .number').hide();
            $('.track-3 .number').hide();
            $('.track-2 .check').hide();
            $('.track-3 .check').hide();
            $('.track-data-1').show();
            $('.track-data-2').hide();
            $('.track-data-3').hide();
         });
          



         $('.track-2').on('click', function(){
            $(this).find('.track-data').show();
             $('.track-2 .check').hide();
             $('.track-2 .number').show();
             $(this).addClass('track-active');
             $('.track-1 .check').show();
             $('.track-1 .number').hide();
             $('.track-main-1 .tack-default').addClass('track-active');
             $('.track-data-1').hide();
            $('.track-data-2').show();
            $('.track-data-3').hide();
         });
          
         $('.track-2 .check').on('click', function(){
            $('.track-2 .number').hide();
            $('.track-3 .number').hide();
            $('.track-2 .check').hide();
            $('.track-3 .check').hide();

            $('.track-main-2 .tack-default').removeClass('track-active');
            $('.track-main-3 .track-3').removeClass('track-active');
         })



         $('.track-3').on('click', function(){
            $(this).find('.track-data').show();
             $(this).find('.check').hide();
             $(this).find('.number').show();
             $(this).addClass('track-active');
             $('.track-1 .check').show();
             $('.track-1 .number').hide();
             $('.track-2 .check').show();
             $('.track-2 .number').hide();
             $('.track-main-2 .tack-default').addClass('track-active');
             $('.track-data-1').hide();
            $('.track-data-2').hide();
            $('.track-data-3').show();
         });
      
      });



$(function() {
  $(".clickTrack2").click(function() {
    $(".trackFor2").addClass('track-active');
      $(this).find('.track-2').addClass('track-active');
  });

  $(".clickTrack3").click(function() {
    $(".trackFor3").addClass('track-active');
     $('.track-3 .number').show();
    $(this).find('.trackFor3').addClass('track-active');    
  });
});



// $(function() {
//   $(".clickTrack2").click(function() {
//     $(".track-2").addClass('track-active');
//   });

//   $(".clickTrack3").click(function() {
//     $(".track-3").addClass('track-active');
//        $('.track-3 .number').show();
//   });
// });

// $(this).find('ul').slideToggle();



      // $(document).ready(function(){
   
      //   $('.track-1').on('click', function(){
      //       $('.track-1 .check').hide();
      //        $(this).addClass('track-active');
      //        $('.track-1 .check').show();
      //        $('.track-main-1 .tack-default').removeClass('track-active');
      //        $('.track-main-2 .tack-default').removeClass('track-active');
      //        $('.track-main-2 .track-2').removeClass('track-active');
      //        $('.track-main-3 .track-3').removeClass('track-active');
      //        $('.track-2 .number').hide();
      //       $('.track-3 .number').hide();
      //       $('.track-2 .check').hide();
      //       $('.track-3 .check').hide();
      //       $('.track-data-1').show();
      //       $('.track-data-2').hide();
      //       $('.track-data-3').hide();
      //    });
          



      //    $('.track-2').on('click', function(){
      //       $(this).find('.track-data').show();
      //        $('.track-2 .check').hide();
      //        $('.track-2 .number').show();
      //        $(this).addClass('track-active');
      //        $('.track-1 .check').show();
      //        $('.track-1 .number').hide();
      //        $('.track-main-1 .tack-default').addClass('track-active');
      //        $('.track-data-1').hide();
      //       $('.track-data-2').show();
      //       $('.track-data-3').hide();
      //    });
          
      //    $('.track-2 .check').on('click', function(){
      //       $('.track-2 .number').hide();
      //       $('.track-3 .number').hide();
      //       $('.track-2 .check').hide();
      //       $('.track-3 .check').hide();

      //       $('.track-main-2 .tack-default').removeClass('track-active');
      //       $('.track-main-3 .track-3').removeClass('track-active');
      //    })



      //    $('.track-3').on('click', function(){
      //       $(this).find('.track-data').show();
      //        $(this).find('.check').hide();
      //        $(this).find('.number').show();
      //        $(this).addClass('track-active');
      //        $('.track-1 .check').show();
      //        $('.track-1 .number').hide();
      //        $('.track-2 .check').show();
      //        $('.track-2 .number').hide();
      //        $('.track-main-2 .tack-default').addClass('track-active');
      //        $('.track-data-1').hide();
      //       $('.track-data-2').hide();
      //       $('.track-data-3').show();
      //    });
      
      // });

