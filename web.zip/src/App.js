import React from 'react';
// import "../src/assets/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../src/assets/css/bootnavbar.css";
import "../src/assets/css/style.css";
import "../src/assets/css/owl.carousel.min.css";
import "../src/assets/css/owl.theme.default.min.css";

import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "../src/assets/css/style.css";


import Header from './components/Header';
import HeroSlider from './components/HeroSlider';
import PopularCourses from './components/PopularCourses';
import LiveBaner from './components/LiveBaner';
import SearchCity from './components/SearchCity';
import SearchCourses from './components/SearchCourses';
import LiveBanner2 from './components/LiveBanner2';
import SearchTests from './components/SearchTests';
import SearchServices from './components/SearchServices';
import EducationPartners from './components/EducationPartners';
import PeopleSay from './components/PeopleSay';
import GetInTouch from './components/GetInTouch';
import OurPartners from './components/OurPartners';
import Footer from './components/Footer';

const App = () => {
  return (
    <>
    <Header/>
    <HeroSlider/>
    <PopularCourses/>
    <LiveBaner/>
    <SearchCity/>
    <SearchCourses/>
    <LiveBanner2/>
    <SearchTests/>
    <SearchServices/>
    <EducationPartners/>
    <PeopleSay/>
    <GetInTouch/>
    <OurPartners/>
    <Footer/>
    </>
  )
}

export default App
